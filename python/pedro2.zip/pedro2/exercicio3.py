#Exercício 3: Operações Aritméticas
#
#Descrição: Crie um programa que receba dois números inteiros do usuário e calcule a soma, a subtração, a multiplicação e a divisão desses números. Exiba os resultados na tela.
#
#Instruções:
#
#Solicite ao usuário para inserir dois números inteiros.
#Realize as operações aritméticas básicas (soma, subtração, multiplicação e divisão).
#Exiba os resultados das operações.

num1 = input("Insira um número: ")
num1 = int(num1)
num2 = input("Insira um número: ")
num2 = int(num2)
print(num1 + num2)
print(num1 - num2)
print(num1 / num2)
print(num1 * num2)