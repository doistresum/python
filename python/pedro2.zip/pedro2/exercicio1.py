
#EXERCICIO 1

#int
num1=1
type(num1)

#float
num2=1.5
type(num2)

#string
nome="pedro"
type(nome)

#booleano
verde = True
type(verde)

