#Descrição: Crie um programa que solicite ao usuário para inserir um número em formato de string, converta esse número para um inteiro e calcule o dobro desse número. Mostre o resultado na tela.
#
#Instruções:
#
#Peça ao usuário para inserir um número.
#Converta a entrada do usuário para um tipo inteiro.
#Calcule o dobro do número.
#Exiba o resultado.


num = input("Insira um número: ")
num = int(num)
print(num*2)