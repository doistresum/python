#Exercício 1: Exibindo Mensagens com print() 2 Pontos
#Escreva um programa que exiba três mensagens diferentes no console usando a função print(). As mensagens devem ser:
#
#Uma saudação.
#Uma citação famosa de sua escolha.
#Uma despedida.
#Exemplo de Saída:
#Olá, bem-vindo ao programa!
#"A persistência é o caminho do êxito." - Charles Chaplin
#Até logo!

saudacao = "Viva,"
quote = "é muito ano a virar frango."
despedida = "Adeus!"

print(saudacao, quote, despedida)